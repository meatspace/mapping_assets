-------------------
Combine Door Small
-------------------
V.1.4
By @SassyRoess

A smaller take on a combine panel door, based on the original asset. Material has been made as lore accurate as possible.
Alternative skins: 
	1: Quarantine door
	2: A cleaner HL-Alyx style
	3: Same as the previous texture, without the combine logo.

Materials, models and source files are included. Please feel free to edit, remix and re-appropriate this asset.

Credit is appreciated, but not mandatory. This asset may not be used in a commercial product without authorization
by the original author. If you would like to use this asset in a commercial product, contact me at sasroess@yahoo.com.au

This work is licensed under Creative Commons Attribution-NonCommercial 4.0 International. 
To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/