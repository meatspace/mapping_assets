Made by Dana Cief / Ciefstatten

The assets in this zip file are provided “AS IS” for Source Engine games, mods and levels. Feel free to use, archive, and redistribute with attribution.