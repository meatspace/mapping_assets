A collection of props extracted and/or remade from HL2's trash composite models for mappers to use. Folder structure is set up to be dropped into the custom folder of Half-Life 2, can otherwise be used by any Source mod by directly adding the files. Note that it makes alterations to some script files! Specifically:

surfaceproperties.txt
- added "plasticbag" surfaceprop
- removed metal box break sounds from "popcan" surfaceprop (otherwise the 001a spray can makes a large metal breaking sound when hit)

games_sounds_physics.txt
- added entries related to the "plasticbag" surface prop


All models are set up to function as prop_physics, unless they have the "_ragdoll" suffix.


Notes about some specific props with special behaviors:
- The two takeout container physics models will break into their ragdoll counterparts.
- The spray can 001a model will cause a paint splat when punted by the gravity gun, and breaks into the 001b model (which does not splat).
- The base coffee cup model will break into the _cup and _lid models.


Original models by Valve, extractions/recreations by Sierra Foxtrot (aka Sage J. Fox).
Some ep2 sounds are included (with renames) to enable functionality in base source games. Custom sounds edited by Sierra Foxtrot from samples provided by PacDV.com ( https://www.pacdv.com/sounds/index.html ). Credit not necessary, but appreciated!