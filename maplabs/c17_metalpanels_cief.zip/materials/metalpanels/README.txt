Made by Dana Cief | @Ciefstatten
For exclusive use in Source Engine games, mods and Map Labs entries with credit (keep this TXT in files)
NOTE: These are built for use in Mapbase, if you plan to use on retail HL2, please adapt the shader header accordingly.

For modification and/or use in other engines, you can get the Smart Material and Higher Quality Exports here!
https://danacief.gumroad.com/l/yslku

Do not sell or otherwise profit from this collection. Do not modify without explicit permission or redistribute without credit.