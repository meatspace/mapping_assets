This is a collection of gate assets based on Arkane's Return To Ravenholm. 
Making them was made possible thanks to Noclip's gameplay footage and release of some of Arkane's concept art. 
The pack includes 8 models made from scratch, with custom textures. 
Each have LOD settings and detailed collision. They're compiled to be passable for bullets (contents 'grate') except for the green metal ones (contents 'solid'; they instead have detailed collision for the wires, so you can still shoot through parts of the model). 
If you want to have texture shadows from them you'll need to add these models in your lights.rad. 

Meshes by Cvoxalury, textures by A. Shift. Original designs by Arkane Studios. 
Released under Creative Commons. Use them however you like, just give proper credit if you do.
