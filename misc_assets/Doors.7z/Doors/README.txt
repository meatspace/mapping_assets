Textures by "Valve"

Frame models by "Dynamic" (me)

Door01_Left_Medium by "Grenade Man" on FacePunch (rip)
Door03_Left_Medium by Myself