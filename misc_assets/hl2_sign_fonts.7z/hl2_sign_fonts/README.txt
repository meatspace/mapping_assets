
whynotll83 https://steamcommunity.com/id/whynotll83/  found these fonts on the valve cut content discord

(I vizzys, https://steamcommunity.com/id/Viz/ did find the fonts myself after they identified them and I placed them in this folder for you all. aside from symbola which was provided to me graciously)

anyway, these are some of the fonts seen on various half-life 2 sign textures that valve used so you too can recreate such things for your maps, have fun