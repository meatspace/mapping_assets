VERSION 1.0

Made by GrenadeMan, released on Facepunch Mapping section


This is a collection of additional door models for use with the prop_door_rotating entity. 
All models and textures have been compiled for source engine EP1 and work in all currently available engine versions.

CONTENTS:



-- door_test_full.vmf

a zoo containing all the door models and suggested door frame setups for all of them - compile it yourself and enjoy



models/props_c17/

-- door01_addf and door01_addg (MODELS)

these are hexed versions of door01_left from ep1's pak file 
they contain additional skins for the standard door model
they should work exactly the same as door01_left, any problems should be reported 
skin 0 is the same on all models, due to restrictions

-- door01_left_medium, door01_left_small, door01_addf_medium, door01_addf_small, door01_addg_medium and  door01_addg_small (MODELS)

these are smaller versions of the standard door model along with variants for additional skins
I had to decompile door01_left in order to make it smaller, but as far as I can tell decompiling didn't cause any issues
any problems shuld be reported
medium is 90x40 and small is 80 x 36 - dimensions are not perfect 

materials/models/props_c17/

-- door skins door01f_skin2-14 and door01g_skin2-14

no bumpmaps unfortunately - both because of consistency with dafault door textures and because it would take a long time to make them
I DID NOT MAKE ANY OF THE SKINS, ALL OF THEM ARE MADE BY VALVE 
if you try to edit them you will notice that .vmt's dont always point to the correspondint .vtf's - sorry for the mess

materials/doorpack/

-- some lightmappedgeneric materials to help with doorframe creation



IF YOU ENCOUNTER ANY PROBLEMS, FIRST CHECK IF THEY ARE PRESENT IN THE STANDARD VALVE DOOR MODEL BEFORE REPORTING THEM




LICENSE:

Do whatever you want with it, dont need to credit me, have fun.







