STORY.ID = 4
STORY.Content = {
		"It's a little sad I suppose. As an animal lover she should have known better. I'm not really one to judge though I suppose.",
		"Moving on. On my left lies a small child. He lived a happy although short life.",
		"Hear His tale and learn."
	}
STORY.Rate = .1 // characters/second
STORY.Brother = 5