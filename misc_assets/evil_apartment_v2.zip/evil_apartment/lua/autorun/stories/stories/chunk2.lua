STORY.ID = 2
STORY.Content = {
			"There are two others on my left and on my right.", 
			"I can see their stories. My senses, once complicated and overrated, have been reduced to a beautiful simplicity. All that remains are words.", 
			"To my right lies an woman, once an indescribable beauty.", 
			"Hear her tale and learn."
		}
STORY.Rate = .1 // 10 characters/second
STORY.Sound = "sunabouzu/stories1.wav"
STORY.Brother = 3