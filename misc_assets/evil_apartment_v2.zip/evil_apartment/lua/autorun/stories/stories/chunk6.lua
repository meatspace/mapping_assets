STORY.ID = 6
STORY.Content = {
		"He found a packet of red powder."
		}	
STORY.Rate = .2 // characters/second
STORY.Brother = 7