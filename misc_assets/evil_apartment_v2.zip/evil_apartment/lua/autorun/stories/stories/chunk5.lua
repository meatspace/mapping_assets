STORY.ID = 5
STORY.Content = {
		"The small boy lived on a farm close to the apartment. He walks confidently down the road, head held high with pride and joy. Today the boy was an adult, he thought, he had been asked to walk down to town and get food! Surely this meant he was a grown up now.",
		"The sky above him was smiling. Perfectly blue, no clouds to obscure the sun's generous light. Nature was alive that day to be sure. Birds, rabbits, deer, even the flowers and trees seemed lively. The boy passed a lake. Sunlight reflecting off the water creating a wave of brilliant sparkles. The boy stopped by the lake side and stared at the water for hours.",
		"As the boy gets up something appears out of the corner of his eye."
		}	
STORY.Rate = .075 // characters/second
STORY.Sound = "sunabouzu/stories3.wav"
STORY.Brother = 6