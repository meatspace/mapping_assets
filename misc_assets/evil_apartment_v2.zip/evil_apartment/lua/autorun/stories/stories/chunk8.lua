STORY.ID = 8
STORY.Content = {
		"Pretty depressing huh?",
		"The ones left and right of me have long since stopped bothering to cry. Which is good because I can't think when people next to me cry. Annoying.",
		"Me? Well I jumped off of a building that I thought was a hole in the floor. Never was one for angst-filled stories. The flowers let me keep that little personality quirk. In return I let them grow from my husk. The rest of my days are going to be peaceful at least. No worries, no annoyances, just the simplest possible sensations. Gets a bit boring. Sometimes we tell jokes to each other, the kid had a good one. Wanna hear it?",
		"How do you know when it's raining cats and dogs?", 
		"When you step in a poodle.", 
		"Heh. I thought that one was funny but the girl just rolled her eyes in disapproval. At least I think she did. Kind of hard to roll your eyes when they're non-existent but you get the idea. As long as these two stay at my side I should be happy. I can always read some other people's stories on rainy nights.",
		"And trust me, there are plenty of stories."
	}	
STORY.Rate = .075 // characters/second
STORY.Sound = "sunabouzu/stories1.wav"