STORY.ID = 7
STORY.Content = {
		"Foolishly the boy slowly approaches the bag. Curiosity over caution.",
		"The boy's world turns red, head overflowing with the viscous sound of bells. The sound is in his head. One word stays at the front of his mind. Pain.",
		"Vision fades, the boy realizes that something is wrong. Now on the ground clutching at small blades of grass, he calls out for help. The flowers take his mouth next. Now helpless, the boy desperately listens for anyone who heard his call. The flowers take his ears, and his nose just for good measure.",
		"Two men approach. The sight they behold is a common one to them, child or not. Knowingly they take the child in their arms and bury him where the flowers will be able to grow. No funeral.",
		"A last word comes to the boy's head. Helpless."
		}	
STORY.Rate = .075 // characters/second
STORY.Sound = "sunabouzu/stories2.wav"
STORY.Brother = 8