STORY.ID = 1
STORY.Content = {
		"Silence.", 
		"It's funny. Seconds before I hit the bottom my mind would not stop screaming in terror. Now that impossibly loud terror has been replaced with a maddening silence. My legs may have broken, corpse an unrecognisable lump of flesh and bone, but it's irrelevant now.", 
		"With a loud snap, possibly a crunch thrown in, everything I've become conscious of is gone.", 
		"I have never been as happy as I am right now."}
STORY.Rate = .1 // 10 characters/second
STORY.Brother = 2