ITEM.ID = 4
ITEM.Name = "Notebook"
ITEM.Model = "models/items/healthkit.mdl" //The model does not exist yet.
ITEM.Description = "A small notebook I brought with me. I can store any notes I find in this thing."