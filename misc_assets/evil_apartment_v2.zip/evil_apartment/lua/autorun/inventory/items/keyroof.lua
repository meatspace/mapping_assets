ITEM.ID = 9
ITEM.Name = "Roof Key"
ITEM.Model = "models/sunabouzu/inventory_key.mdl"
ITEM.Skin = 4
ITEM.Description = "Found in room 301. I can unlock a door by using this key."
ITEM.CamPos = Vector(0, 128, 128)
ITEM.LookAtPos = Vector(0, -1, 0)
ITEM.FOV = 5