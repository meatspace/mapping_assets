ITEM.ID = 15
ITEM.Name = "Portrait of Erwin Rommel"
ITEM.Model = "models/sunabouzu/puzzle_portrait.mdl" 
ITEM.Skin = 3
ITEM.Description = "A large portrait. I could hang it up on a wall if I wanted to."
ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAtPos = Vector(0, 0, 9)
ITEM.FOV = 70