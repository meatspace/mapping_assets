ITEM.ID = 10
ITEM.Name = "2nd Stairwell Key"
ITEM.Model = "models/sunabouzu/inventory_key.mdl"
ITEM.Skin = 5
ITEM.Description = "Found in room 104. I can unlock a door by using this key."
ITEM.CamPos = Vector(0, 128, 128)
ITEM.LookAtPos = Vector(0, -1, 0)
ITEM.FOV = 5