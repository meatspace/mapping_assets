ITEM.ID = 12
ITEM.Name = "Portrait of Henry II"
ITEM.Model = "models/sunabouzu/puzzle_portrait.mdl" 
ITEM.Description = "A large portrait. I could hang it up on a wall if I wanted to."
ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAtPos = Vector(0, 0, 9)
ITEM.FOV = 70