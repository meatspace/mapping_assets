ITEM.ID = 16
ITEM.Name = "Pliers"
ITEM.Model = "models/props_c17/tools_pliers01a.mdl" 
ITEM.Description = "A pair of Pliers. Pretty handy for forcing containers open, or y'know, fixing stuff."
ITEM.CamPos = Vector(50, 50, 50)
ITEM.LookAtPos = Vector(0, 0, -1)
ITEM.FOV = 22