ITEM.ID = 2
ITEM.Name = "Lighter"
ITEM.Model = "models/weapons/w_lighter.mdl"
ITEM.Description = "My lighter. It's pretty weak as a light source, but if I find any candles around I can light them."
ITEM.CamPos = Vector(0, 128, 128)
ITEM.LookAtPos = Vector(-1, -3, 0)
ITEM.FOV = 5
ITEM.DisableUse = true