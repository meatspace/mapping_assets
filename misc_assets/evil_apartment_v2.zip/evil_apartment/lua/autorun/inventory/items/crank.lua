ITEM.ID = 18
ITEM.Name = "Generator Crank"
ITEM.Model = "models/props_mining/diesel_generator_crank.mdl"
ITEM.Skin = 0
ITEM.Description = "Look at an object and press the use key to use some items."
ITEM.CamPos = Vector(0, 128, 128)
ITEM.LookAtPos = Vector(0, -1, 0)
ITEM.FOV = 22