ITEM.ID = 5
ITEM.Name = "Key to room 104"
ITEM.Model = "models/sunabouzu/inventory_key.mdl"
ITEM.Skin = 0
ITEM.Description = "Found in room 201. I can unlock a door by using this key."
ITEM.CamPos = Vector(0, 128, 128)
ITEM.LookAtPos = Vector(0, -1, 0)
ITEM.FOV = 5