ITEM.ID = 11
ITEM.Name = "Lightbulb"
ITEM.Model = "models/sunabouzu/dark_lightbulb.mdl" 
ITEM.Description = "This was in the bedroom of room 202. It's painted a deep blue, but I don't really know why."
ITEM.CamPos = Vector(0, 128, 128)
ITEM.LookAtPos = Vector(0, -1, 0)
ITEM.FOV = 5