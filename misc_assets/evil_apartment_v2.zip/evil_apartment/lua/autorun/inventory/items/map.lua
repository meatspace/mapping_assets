ITEM.ID = 3
ITEM.Name = "Map"
ITEM.Model = "models/Items/HealthKit.mdl" //The Model does not exist yet.
ITEM.Description = "I'm drawing down a makeshift map of this place as I go. I'll also write down anything of note in the rooms."