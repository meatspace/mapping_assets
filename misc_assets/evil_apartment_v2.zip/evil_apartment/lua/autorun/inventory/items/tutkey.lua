ITEM.ID = 17
ITEM.Name = "Tutorial Key"
ITEM.Model = "models/sunabouzu/inventory_key.mdl"
ITEM.Skin = 0
ITEM.Description = "Look at a door and press the use key to unlock it."
ITEM.CamPos = Vector(0, 128, 128)
ITEM.LookAtPos = Vector(0, -1, 0)
ITEM.FOV = 5