The files inside this scripts folder need to be installed to your garrysmod/garrysmod directory, NOT YOUR ADDONS FOLDER.

All this does is add a new surfaceproperties for the carpets. It adds new footstep sounds for when you step on carpet because I was getting pissed at how carpet textures use the dirt footstep sound.