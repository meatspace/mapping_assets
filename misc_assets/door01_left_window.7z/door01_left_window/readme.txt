made by iiboharz <3

it has 2 skins, one for a clear window and one for a frosted glass window.

installation:
come on you know how to install custom models etc.

credit me maybe idk i dont care

have fun